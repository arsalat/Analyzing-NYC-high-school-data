# Introduction

One of the most controversial issues in the U.S. educational system is the efficacy of standardized tests, and whether they're unfair to certain groups. Given our prior knowledge of this topic, investigating the correlations between SAT scores and demographics might be an interesting angle to take. We could correlate SAT scores with factors like race, gender, income, and more.

The test consists of three sections, each of which has 800 possible points. The combined score is out of 2,400 possible points (while this number has changed a few times, the data set for our project is based on 2,400 total points). Organizations often rank high schools by their average SAT scores. The scores are also considered a measure of overall school district quality.


After exploring the datasets, we can conclude the following:

Only high school students take the SAT, so we'll want to focus on high schools.
New York City is made up of five boroughs, which are essentially distinct regions.
New York City schools fall within several different school districts, each of which can contains dozens of schools.
Our data sets include several different types of schools. We'll need to clean them so that we can focus on high schools only.
Each school in New York City has a unique code called a DBN, or district borough number.
Aggregating data by district will allow us to use the district mapping data to plot district-by-district differences.


```python
# We'll read each file into a pandas dataframe, and then store all of the dataframes in a dictionary. 
#This will give us a convenient way to store them, and a quick way to reference them later on.


import pandas as pd
import numpy
import re

data_files = [
    "ap_2010.csv",
    "class_size.csv",
    "demographics.csv",
    "graduation.csv",
    "hs_directory.csv",
    "sat_results.csv"
]

data = {}

for f in data_files:
    d = pd.read_csv("schools/{0}".format(f))
    data[f.replace(".csv", "")] = d
```


```python
#reading in the survey data and combining the survey dataframes

all_survey = pd.read_csv("schools/survey_all.txt", delimiter="\t", encoding='windows-1252')
d75_survey = pd.read_csv("schools/survey_d75.txt", delimiter="\t", encoding='windows-1252')
survey = pd.concat([all_survey, d75_survey], axis=0)

survey["DBN"] = survey["dbn"]

survey_fields = [
    "DBN", 
    "rr_s", 
    "rr_t", 
    "rr_p", 
    "N_s", 
    "N_t", 
    "N_p", 
    "saf_p_11", 
    "com_p_11", 
    "eng_p_11", 
    "aca_p_11", 
    "saf_t_11", 
    "com_t_11", 
    "eng_t_11", 
    "aca_t_11", 
    "saf_s_11", 
    "com_s_11", 
    "eng_s_11", 
    "aca_s_11", 
    "saf_tot_11", 
    "com_tot_11", 
    "eng_tot_11", 
    "aca_tot_11",
]
survey = survey.loc[:,survey_fields]
data["survey"] = survey
```


```python
#cleaning the data to select the columns we need. These columns will give us aggregate survey data about how parents, teachers, and students feel about school safety, academic performance, and more. 
#It will also give us the DBN, which allows us to uniquely identify the school.

data["hs_directory"]["DBN"] = data["hs_directory"]["dbn"]

def pad_csd(num):
    string_representation = str(num)
    if len(string_representation) > 1:
        return string_representation
    else:
        return "0" + string_representation
    
data["class_size"]["padded_csd"] = data["class_size"]["CSD"].apply(pad_csd)
data["class_size"]["DBN"] = data["class_size"]["padded_csd"] + data["class_size"]["SCHOOL CODE"]
```


```python
#converting SAT score columns to numeric so we add a column for the total score

cols = ['SAT Math Avg. Score', 'SAT Critical Reading Avg. Score', 'SAT Writing Avg. Score']
for c in cols:
    data["sat_results"][c] = pd.to_numeric(data["sat_results"][c], errors="coerce")


# adding the scores as a new column sat_score in sat_results
data['sat_results']['sat_score'] = data['sat_results'][cols[0]] + data['sat_results'][cols[1]] + data['sat_results'][cols[2]]


```


```python
# parse the latitude and longitude coordinates for each school to map the schools and uncover any geographic patterns in the data

def find_lat(loc):
    coords = re.findall("\(.+, .+\)", loc)
    lat = coords[0].split(",")[0].replace("(", "")
    return lat

def find_lon(loc):
    coords = re.findall("\(.+, .+\)", loc)
    lon = coords[0].split(",")[1].replace(")", "").strip()
    return lon

data["hs_directory"]["lat"] = data["hs_directory"]["Location 1"].apply(find_lat)
data["hs_directory"]["lon"] = data["hs_directory"]["Location 1"].apply(find_lon)

data["hs_directory"]["lat"] = pd.to_numeric(data["hs_directory"]["lat"], errors="coerce")
data["hs_directory"]["lon"] = pd.to_numeric(data["hs_directory"]["lon"], errors="coerce")
```


```python
# further cleaning before we combine the datasets

class_size = data["class_size"]
class_size = class_size[class_size["GRADE "] == "09-12"]
class_size = class_size[class_size["PROGRAM TYPE"] == "GEN ED"]

class_size = class_size.groupby("DBN").agg(numpy.mean)
class_size.reset_index(inplace=True)
data["class_size"] = class_size

data["demographics"] = data["demographics"][data["demographics"]["schoolyear"] == 20112012]

data["graduation"] = data["graduation"][data["graduation"]["Cohort"] == "2006"]
data["graduation"] = data["graduation"][data["graduation"]["Demographic"] == "Total Cohort"]
```

It makes sense that the number of students at a school who took AP exams would be highly correlated with the school's SAT scores. Let's explore this relationship. 

We'll look at the percentage of students in each school who took at least one AP exam.


```python
cols = ['AP Test Takers ', 'Total Exams Taken', 'Number of Exams with scores 3 4 or 5']

for col in cols:
    data["ap_2010"][col] = pd.to_numeric(data["ap_2010"][col], errors="coerce")
```


```python
# combining the datasets

combined = data["sat_results"]

combined = combined.merge(data["ap_2010"], on="DBN", how="left")
combined = combined.merge(data["graduation"], on="DBN", how="left")

to_merge = ["class_size", "demographics", "survey", "hs_directory"]

for m in to_merge:
    combined = combined.merge(data[m], on="DBN", how="inner")

combined = combined.fillna(combined.mean())
combined = combined.fillna(0)
```


```python
#Add a school district column for mapping

def get_first_two_chars(dbn):
    return dbn[0:2]

combined["school_dist"] = combined["DBN"].apply(get_first_two_chars)
```


```python
# now we are ready to discover correlations, create plots, and then make maps. 

correlations = combined.corr()
correlations = correlations["sat_score"]
print(correlations)
```

    SAT Critical Reading Avg. Score    0.986820
    SAT Math Avg. Score                0.972643
    SAT Writing Avg. Score             0.987771
    sat_score                          1.000000
    AP Test Takers                     0.523140
                                         ...   
    priority08                              NaN
    priority09                              NaN
    priority10                              NaN
    lat                               -0.121029
    lon                               -0.132222
    Name: sat_score, Length: 67, dtype: float64



```python
# Remove DBN since it's a unique identifier, not a useful numerical value for correlation.
survey_fields.remove("DBN")
```


```python
# Plotting survey correlations

%matplotlib inline
combined.corr()["sat_score"][survey_fields].plot.bar()

```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f5491465070>




    
![png](output_14_1.png)
    


An interesting fact to note from this bar chart is that saf_t_11 and saf_s_11, which measure how teachers and students perceive safety at school, correlated highly with sat_score. Let's dig into this deeper and try to figure out which schools have low safety scores


```python
# lets investigate the relationship between safety scores by plotting saf_s_11 column vs. the sat_score in combined

combined.plot.scatter("saf_s_11", "sat_score")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f548e9e28b0>




    
![png](output_16_1.png)
    


We can conlude that higher safety ratings resulted in an increase in sat score, because students perform better in a safer environment where schools and homes are both safer.


```python
# Compute the average safety score for each borough.

boros = combined.groupby("boro").agg(numpy.mean)["saf_s_11"]
print(boros)
```

    boro
    Bronx            6.606577
    Brooklyn         6.370755
    Manhattan        6.831370
    Queens           6.721875
    Staten Island    6.530000
    Name: saf_s_11, dtype: float64


There are a few columns that indicate the percentage of each race at a given school:

white_per
asian_per
black_per
hispanic_per

By plotting out the correlations between these columns and sat_score, we can determine whether there are any racial differences in SAT performance.


```python
# Investigating racial differences in SAT scores

race = ["white_per", "asian_per", "black_per", "hispanic_per"]
combined.corr()["sat_score"][race].plot.bar()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f548f3c8460>




    
![png](output_20_1.png)
    


White and Asian students tend to perform better on SAT as we can see from the positive correlation. Black and hispanic percentages correlate negatively with sat score which means students from these bacgrounds tend to perform poorly.


```python
# Explore schools with low SAT scores and high values for hispanic_per.

combined.plot.scatter("hispanic_per", "sat_score")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f54cdba2c10>




    
![png](output_22_1.png)
    


The scatter plot shows that the SAT score decreases with an increase in hispanic percentages in an area.


```python
# researching schools with a hispanic_per greater than 95%.

hisp = combined[combined["hispanic_per"] > 95]
print(hisp["SCHOOL NAME"])
```

    44                         MANHATTAN BRIDGES HIGH SCHOOL
    82      WASHINGTON HEIGHTS EXPEDITIONARY LEARNING SCHOOL
    89     GREGORIO LUPERON HIGH SCHOOL FOR SCIENCE AND M...
    125                  ACADEMY FOR LANGUAGE AND TECHNOLOGY
    141                INTERNATIONAL SCHOOL FOR LIBERAL ARTS
    176     PAN AMERICAN INTERNATIONAL HIGH SCHOOL AT MONROE
    253                            MULTICULTURAL HIGH SCHOOL
    286               PAN AMERICAN INTERNATIONAL HIGH SCHOOL
    Name: SCHOOL NAME, dtype: object


From the key words in the school names (learning school, international, multicultural, bridges, language), it seems like a lot of sturents in thise schools are immigrants which would explain a lower SAT score owing to the language barrier.


```python
# researching schools with a hispanic_per less than 10% and an average SAT score greater than 1800.

hisp_greater = combined[(combined["hispanic_per"] < 10) & (combined["sat_score"] > 1800)]
print(hisp_greater["School Name"])
```

    37                    STUYVESANT HIGH SCHOOL
    151             BRONX HIGH SCHOOL OF SCIENCE
    187           BROOKLYN TECHNICAL HIGH SCHOOL
    327    QUEENS HIGH SCHOOL FOR THE SCIENCES A
    356      STATEN ISLAND TECHNICAL HIGH SCHOOL
    Name: School Name, dtype: object


From the keywords in the school names, it seems like that these schools are geared towards scintific and technical learning which is why their students perform better on SAT scores.


```python
# Investigating gender differences in SAT scores.

gender = ["male_per", "female_per"]
combined.corr()["sat_score"][gender].plot.bar()

```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f549349e7c0>




    
![png](output_28_1.png)
    


High male percentages correlate negatively with SAT score, while high female percentages correlate positively. This implies that females tend to do better on the SAT. However none of these correlations are strong enough to make a solid conclusion.


```python
# Investigating schools with high SAT scores and a high female_per.

combined.plot.scatter("female_per", "sat_score")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f548e8ec7f0>




    
![png](output_30_1.png)
    


Higher sat scores are clustered wih schools around 60 to 80 percent of females, which confirms that females perform better on SAT than males.


```python
# investigating any schools with a female_per greater than 60% and an average SAT score greater than 1700.

female_greater = combined[(combined["female_per"] > 60) & (combined["sat_score"] > 1700)]
print(female_greater["School Name"])
```

    5            BARD HIGH SCHOOL EARLY COLLEGE
    26            ELEANOR ROOSEVELT HIGH SCHOOL
    60                       BEACON HIGH SCHOOL
    61     FIORELLO H. LAGUARDIA HIGH SCHOOL OF
    302             TOWNSEND HARRIS HIGH SCHOOL
    Name: School Name, dtype: object


These appear to specialized private high schools with a lot of funding and high academic standards. 


```python
# calculating the percentage of students in each school that took an AP exam.
combined["ap_per"] = combined["AP Test Takers "] / combined["total_enrollment"]
```


```python
# investigating the relationship between AP scores and SAT scores

combined.plot.scatter("ap_per", "sat_score")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f548e94e280>




    
![png](output_35_1.png)
    


No strong correlation can be found between the percentage of students taking ap exams and SAT score.

Conclusion:

It can be concluded that SAT scores vary among students belonging to different racial backgrounds and living in economically varying neighbourhoods.
